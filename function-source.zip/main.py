import requests
import json

def getNews(request):
    """Responds to any HTTP request.
    Args:
        request (flask.Request): HTTP request object.
    Returns:
        The response text or any set of values that can be turned into a
        Response object using
        `make_response <http://flask.pocoo.org/docs/1.0/api/#flask.Flask.make_response>`.
    """
    request_json = request.get_json()
    if request.args and 'clientAddr' in request.args:
        url = 'http://api.ipstack.com/{}?access_key=9654c1bacd7ae54c1eb09a60b315bab8'.format(request.args['clientAddr'])
        response = requests.get(url).json()
        url = ('http://newsapi.org/v2/top-headlines?'
                'country={}&'
                'apiKey=665ea6fd978c4ac686bb0456f271ea3a'.format(response['country_code']))
        response = json.dumps(requests.get(url).json())
        return response
    elif request_json and 'remoteAddr' in request_json:
        return request_json['remoteAddr']
    else:
        return f'Malformed Request!'
